import numpy as np

# Ring Buffer
class RingBuffer:
    def __init__(self, size):
        self.size = size
        self.data = np.zeros((size, 3))
        self.index = 0
        self.full = False
        self.count = 0  # track valid entries

    def append(self, own_price, comp_price, demand):
        self.data[self.index] = [own_price, comp_price, demand]
        self.index = (self.index + 1) % self.size
        if self.count < self.size:
            self.count += 1
        if self.index == 0:
            self.full = True

    def get(self):
        # return only valid data
        if self.count == 0:
            return np.empty((0,3))
        if self.full:
            return np.roll(self.data, -self.index, axis=0)
        else:
            return self.data[:self.count]

# Pricing function
def p(t, history=None, info_dump=None):
    if info_dump is None:
        info_dump = {"buffer": RingBuffer(20), "last_price": 75.0}  # start mid-range

    own_price = info_dump["last_price"]
    comp_price = history.get("comp_price", 75.0) if history else 75.0
    demand = history.get("demand", 4.0) if history else 4.0

    info_dump["buffer"].append(own_price, comp_price, demand)
    data = info_dump["buffer"].get()

    # Compute averages safely
    if len(data) > 0:
        avg_comp_price = np.mean(data[:, 1])
        avg_demand = np.mean(data[:, 2])
    else:
        avg_comp_price = comp_price
        avg_demand = demand

    # Pricing logic
    alpha = 0.3
    beta = 0.8  # strong competitor reaction
    target_demand = 4.0

    new_price = own_price + alpha * (target_demand - demand) + beta * (avg_comp_price - own_price)
    new_price = np.clip(new_price, 30.0, 120.0)

    info_dump["last_price"] = new_price
    return new_price, info_dump