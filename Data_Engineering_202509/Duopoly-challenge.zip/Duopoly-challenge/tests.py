# ===========================
import unittest
import numpy as np
from duopoly import RingBuffer, p

class TestRingBuffer(unittest.TestCase):
    def test_rollover(self):
        buf = RingBuffer(3)
        buf.append(10, 20, 1)
        buf.append(11, 21, 2)
        buf.append(12, 22, 3)
        buf.append(13, 23, 4)  # should overwrite first
        data = buf.get()
        self.assertEqual(data.shape, (3, 3))
        self.assertTrue(np.allclose(data[-1], [13.0, 23.0, 4.0]))

class TestPricingFunction(unittest.TestCase):
    def test_pricing_within_bounds(self):
        price, info = p(t=0, history=None, info_dump=None)
        self.assertTrue(30.0 <= price <= 120.0)

    def test_price_reacts_to_competitor(self):
        price, info = p(t=0, history=None, info_dump=None)  # fresh start
        history = {"comp_price": 40.0, "demand": 1.0}
        new_price, info = p(t=1, history=history, info_dump=info)
        
        self.assertTrue(30.0 <= new_price <= 120.0)
        self.assertTrue(abs(new_price - history["comp_price"]) <= abs(price - history["comp_price"]))

if __name__ == "__main__":
    unittest.main()