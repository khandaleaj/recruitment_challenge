"""
Toy simulator to visualize state evolution offline.
This is NOT part of the DPC submission, just for local sanity checks.
"""
import numpy as np
from duopoly import p

def fake_env_run(seed=1, T=30):
    rng = np.random.default_rng(seed)

    # Simple hidden demand model: q = a + b*p + c*pc + d*stockC + e*time + noise
    a, b, c, d, e = 5.0, -0.06, 0.03, -0.5, 2.0
    comp_price = 50.0
    comp_has = True
    info = None
    prices_hist = None
    demand_hist = None

    for day in range(1, T+1):
        # Prepare history dict for pricing function
        history = {"comp_price": comp_price, "demand": demand_hist[-1] if demand_hist is not None else 4.0}

        # Call pricing function
        price, info = p(day, history, info)

        # Simulate competitor simple policy
        comp_price = np.clip(0.8 * comp_price + 0.2 * (price + rng.normal(0, 4)), 5, 95)

        # Realized demand
        t_norm = 1.0 - (day - 1)/100.0
        mu = a + b*price + c*comp_price + d*(1.0 if comp_has else 0.0) + e*t_norm
        q = np.clip(mu + rng.normal(0, 0.5), 0, 10)

        # Update histories
        if prices_hist is None:
            prices_hist = np.array([[price],[comp_price]], dtype=float)
            demand_hist = np.array([q], dtype=float)
        else:
            prices_hist = np.hstack([prices_hist, np.array([[price],[comp_price]])])
            demand_hist = np.hstack([demand_hist, np.array([q])])

    return prices_hist, demand_hist

if __name__ == "__main__":
    P, Q = fake_env_run()
    print("Own price last 5:", P[0,-5:])
    print("Comp price last 5:", P[1,-5:])
    print("Demand last 5:", Q[-5:])
